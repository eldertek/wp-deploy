<?php

declare(strict_types=1);

namespace Staatic\WordPress\Service\Encrypter;

use Exception;

class InvalidValueException extends Exception
{
}
