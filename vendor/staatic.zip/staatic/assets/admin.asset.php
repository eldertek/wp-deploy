<?php

namespace Staatic\Vendor;

return array(
    'dependencies' => array('react', 'wp-api-fetch', 'wp-components', 'wp-dom-ready', 'wp-element', 'wp-i18n'),
    'version' => '7b513f460c842157a387'
);
